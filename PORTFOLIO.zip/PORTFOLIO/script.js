var options= {
strings:['UI/UX Desiner.','Full stack Developer'],
typeSpeed:100,
backSpeed:100
};

var typed= new Typed('.typing', options);